using UnityEngine;

public class InteractObject: MonoBehaviour
{
    

    void Start()
    {
        
    }


    void Update()
    {
        
    }
}
