using UnityEngine;

public class NewBehaviourScript : MonoBehaviour
{
    public GameObject text;
   
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Player"))
        {
            collision.CompareTag("Inimigos");
            text.SetActive(true);
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.CompareTag("Player"))
        {
            collision.CompareTag("Inimigos");
            text.SetActive(false);
        }
    }
}
