using UnityEngine;

public class PlayerController : MonoBehaviour
{
    [Header("Player Properties")]
    public float inventario;
    public float moveSpeed = 10;
    private Rigidbody2D rb;
    private Animator anime;
    
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        anime = GetComponent<Animator>();
    }

    void Update()
    {
        float x = Input.GetAxis("HORIZONTAL0");
        float y = Input.GetAxis("VERTICAL0");
        rb.velocity = new Vector2(x, y) * moveSpeed;

       if (Input.GetAxis("HORIZONTAL0") != 0)
        {
   
            anime.SetBool("isRight", Input.GetAxis("HORIZONTAL0") > 0);
            anime.SetBool("isLeft", Input.GetAxis("HORIZONTAL0") < 0);
        }
        else
        {
    
            anime.SetBool("isRight", false);
            anime.SetBool("isLeft", false);
        }      

        if (Input.GetAxis("VERTICAL0") != 0)
        {
   
            anime.SetBool("isWalkC", Input.GetAxis("VERTICAL0") > 0);
            anime.SetBool("isWalkB", Input.GetAxis("VERTICAL0") < 0);
        }
        else
        {
   
            anime.SetBool("isWalkC", false);
            anime.SetBool("isWalkB", false);
        }

    }

    private void FixedUpdate()
    {
        anime.SetFloat("Walk", Mathf.Abs(rb.velocity.x));
        anime.SetFloat("Walk", Mathf.Abs(rb.velocity.y));
    }
   
}